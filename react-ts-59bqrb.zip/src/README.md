# 抽奖大转盘

[stackblitz预览地址](https://stackblitz.com/edit/react-ts-59bqrb)

#### 两种实现方式 div & canvas
1. css transform: rotate skew 绘制
2. canvas arc 方法画弧
- 效果图
- ![](./assets/lucky-spin.png)
